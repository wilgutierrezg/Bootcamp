import pandas as pd

serie = pd.Series([10,20,30])

print(serie)