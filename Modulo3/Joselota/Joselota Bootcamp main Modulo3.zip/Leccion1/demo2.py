import numpy as np

a = np.array([5, 9, 10, 2])
print(np.argmax(a)) 